//Variável para receber um campo HTML
var querystring = require("querystring");

function start(response, postData) {
     console.log("Requição Rota start executado");
 
    //HTML
     var body = '<html>'+
        '<head>'+
        '<meta http-equiv="Content-Type" content="text/html; '+
        'charset=UTF-8" />'+
        '</head>'+
        '<body>'+
        '<form action="/upload" method="post">'+
        '<textarea name="text" rows="10" cols="30"></textarea><p>'+
        '<input type="submit" value="Enviar" />'+
        '</form>'+
        '</body>'+
        '</html>';
 
      response.writeHead(200, {"Content-Type": "text/html"});
      response.write(body);
      response.end();
}

//Parâmetro postData recebido pela Função
function upload(response, postData) {
    console.log("Request handler 'upload' executado");
    response.writeHead(200, {"Content-Type": "text/plain"});
    //POST apenas do elemento textfield
    response.write("Enviado " + querystring.parse(postData).text);
    response.end();
}

exports.start = start;
exports.upload = upload;
