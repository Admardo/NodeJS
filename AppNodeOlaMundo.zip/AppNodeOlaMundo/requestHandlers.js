function start(response, route) {
     console.log("Olá Mundo!");
 
     var body = '<html>'+
        '<head>'+
        '<meta http-equiv="Content-Type" content="text/html; '+
        'charset=UTF-8" />'+
        '</head>'+
        '<body>'+
        '<h1>Olá Mundo!</h1>'+
        '<a href="https://admsinformatica.wordpress.com/nodejs/">Conteúdo NodeJS</a><p>'+
        '<a href="https://nodejs.org/pt">NodeJS</a>'+
        '</body>'+
        '</html>';
 
      response.writeHead(200, {"Content-Type": "text/html"});
      response.write(body);
      response.end();
}

exports.start = start;
