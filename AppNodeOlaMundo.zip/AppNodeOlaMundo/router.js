function route(handle, pathname, response) {
    //console.log("Requisição da URL " + pathname);
    
    //Verifica a Rota informada na URL e direciona
    if (typeof handle[pathname] === 'function') {
        handle[pathname](response);
    }
    else {
        console.log("Não há Requisição para a Rota " + pathname);
        response.writeHead(404, {"Content-Type": "text/plain"});
        response.write("404 Not Found");
        response.end();
    }
}

exports.route = route;
